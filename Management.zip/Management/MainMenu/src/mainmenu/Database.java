package mainmenu;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;




public class Database {
    private  Connection conn;
    private  Statement stm ;
    

    public Database(){
    try{    
    Class.forName("com.mysql.jdbc.Driver");
  
    conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/record?zeroDateTimeBehavior=convertToNull","root","");
    stm = conn.createStatement();
    System.out.println("Connected");
    
        }
catch(Exception e ){
    
    System.out.println(" not Connected");
}   
    }
    
    

        
        

}
